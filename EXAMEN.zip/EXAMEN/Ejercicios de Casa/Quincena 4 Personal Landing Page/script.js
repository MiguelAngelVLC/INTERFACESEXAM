// Seleccionamos todos los botones de la sección FAQ
const botones = document.querySelectorAll('section[aria-labelledby="pregFrec"] button'); // Selecciona los tres <button>, dentro de la <secction> con aria-labelledby="pregFrec".

botones.forEach(button => {
    button.addEventListener('click', () => {
        const expandido = button.getAttribute('aria-expanded') === 'true'; // Comparo dos cadenas. Compara si el <button> tiene en aria-expanded="true". (Devuelve boolean).
        const controlador = button.getAttribute('aria-controls'); // Guarda en la variable controlador el valor que tiene aria-controls en este caso es = "pregResp1".
        const respuesta = document.getElementById(controlador); // Busco el valor de antes en el elemento que esta controlado por ese controlador e identificado con un id = "pregResp1".

        // Alternamos el estado ARIA y la visibilidad
        button.setAttribute('aria-expanded', !expandido); // Invierte el estado actual de expandido. // El valor asignado con setAttribute se convierte automáticamente en una cadena de texto, aunque pongas un booleano.
        respuesta.hidden = expandido; // Si hidden es true, el elemento no se muestra. Si hidden es false, el elemento se muestra normalmente.
    });
});
